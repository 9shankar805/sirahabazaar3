import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  Package, Plus, Edit, Trash2, Search, Filter, Download, Upload,
  AlertTriangle, TrendingUp, TrendingDown, BarChart3, Eye, Clock
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

const stockUpdateSchema = z.object({
  productId: z.number(),
  quantity: z.number().min(0),
  type: z.enum(['stock_in', 'stock_out', 'adjustment']),
  reason: z.string().optional()
});

export default function SellerInventory() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [stockFilter, setStockFilter] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);

  const form = useForm<z.infer<typeof stockUpdateSchema>>({
    resolver: zodResolver(stockUpdateSchema),
    defaultValues: {
      quantity: 0,
      type: 'stock_in',
      reason: ''
    }
  });

  // Products query with enhanced error handling and data validation
  const { data: products = [], isLoading: productsLoading, error: productsError, refetch: refetchProducts } = useQuery({
    queryKey: ['/api/products/store', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error('User ID required');
      const response = await fetch(`/api/products/store?userId=${user.id}`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: !!user?.id,
    staleTime: 30000, // 30 seconds
    refetchOnWindowFocus: false,
    retry: (failureCount, error) => {
      if (failureCount < 3) return true;
      console.error('Products fetch failed:', error);
      return false;
    }
  });

  // Inventory logs query with enhanced error handling
  const { data: inventoryLogs = [], isLoading: logsLoading, refetch: refetchLogs } = useQuery({
    queryKey: ['/api/seller/inventory', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error('User ID required');
      const response = await fetch(`/api/seller/inventory?userId=${user.id}`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: !!user?.id,
    staleTime: 30000,
    refetchOnWindowFocus: false
  });

  // Stock update mutation with enhanced error handling and immediate refresh
  const updateStockMutation = useMutation({
    mutationFn: async (data: z.infer<typeof stockUpdateSchema>) => {
      const response = await fetch('/api/seller/inventory/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update stock');
      }
      return response.json();
    },
    onSuccess: async () => {
      toast({
        title: "Stock Updated",
        description: "Product inventory has been updated successfully",
      });
      
      // Force immediate data refresh
      await Promise.all([
        refetchProducts(),
        refetchLogs()
      ]);
      
      setIsUpdateDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      console.error('Stock update error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update stock",
        variant: "destructive"
      });
    }
  });

  const handleStockUpdate = (data: z.infer<typeof stockUpdateSchema>) => {
    updateStockMutation.mutate(data);
  };

  const openUpdateDialog = (product: any) => {
    setSelectedProduct(product);
    form.setValue('productId', product.id);
    setIsUpdateDialogOpen(true);
  };

  // Filter products based on search and stock level
  const filteredProducts = Array.isArray(products) ? products.filter((product: any) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStock = stockFilter === 'all' || 
      (stockFilter === 'low' && (product.stock || 0) < 10) ||
      (stockFilter === 'out' && (product.stock || 0) === 0) ||
      (stockFilter === 'available' && (product.stock || 0) > 0);
    
    return matchesSearch && matchesStock;
  }) : [];

  const lowStockCount = Array.isArray(products) ? products.filter((p: any) => (p.stock || 0) < 10).length : 0;
  const outOfStockCount = Array.isArray(products) ? products.filter((p: any) => (p.stock || 0) === 0).length : 0;
  const totalValue = Array.isArray(products) ? products.reduce((sum: number, p: any) => sum + ((p.stock || 0) * parseFloat(p.price)), 0) : 0;

  // Check authentication and admin approval
  if (!user || user.role !== 'shopkeeper') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-red-600">Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-muted-foreground">
              You need to be a shopkeeper to access inventory management.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (user.role === 'shopkeeper' && (user as any).status !== 'active') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <CardTitle className="text-center text-yellow-600">Pending Admin Approval</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="mx-auto w-16 h-16 rounded-full bg-yellow-100 dark:bg-yellow-900/20 flex items-center justify-center">
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
            <p className="text-muted-foreground">
              Your seller account is pending approval from our admin team. You cannot access inventory management until approved.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/">
                <Button variant="outline">Go to Homepage</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Package className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Inventory Management</h1>
                <p className="text-sm text-muted-foreground">Manage your product stock and inventory</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Link href="/seller/products/add">
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </Link>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Inventory Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Products</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Array.isArray(products) ? products.length : 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Low Stock</CardTitle>
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{lowStockCount}</div>
              <p className="text-xs text-muted-foreground">Items below 10 units</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
              <TrendingDown className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{outOfStockCount}</div>
              <p className="text-xs text-muted-foreground">Items need restocking</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{totalValue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Total stock value</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={stockFilter} onValueChange={setStockFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Products</SelectItem>
                  <SelectItem value="available">In Stock</SelectItem>
                  <SelectItem value="low">Low Stock</SelectItem>
                  <SelectItem value="out">Out of Stock</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Products Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Product Inventory
              {productsLoading && (
                <div className="text-sm text-muted-foreground">Loading...</div>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {productsError && (
              <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <div className="text-red-800 dark:text-red-200 font-medium">Error loading products</div>
                <div className="text-red-600 dark:text-red-400 text-sm mt-1">
                  {productsError.message}
                </div>
                <Button 
                  onClick={() => refetchProducts()} 
                  variant="outline" 
                  size="sm" 
                  className="mt-2"
                >
                  Retry
                </Button>
              </div>
            )}
            
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>SKU</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Current Stock</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productsLoading ? (
                    Array.from({ length: 5 }).map((_, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse"></div>
                            <div>
                              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-32"></div>
                              <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-48 mt-1"></div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell><div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-16"></div></TableCell>
                        <TableCell><div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-12"></div></TableCell>
                        <TableCell><div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-16"></div></TableCell>
                        <TableCell><div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-20"></div></TableCell>
                        <TableCell><div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-16"></div></TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <div className="h-8 w-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                            <div className="h-8 w-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"></div>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : filteredProducts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8">
                        <div className="text-muted-foreground">
                          {searchTerm || stockFilter !== 'all' ? 'No products match your filters' : 'No products found'}
                        </div>
                        {!searchTerm && stockFilter === 'all' && (
                          <Link href="/seller/products/add" className="inline-block mt-2">
                            <Button size="sm">Add Your First Product</Button>
                          </Link>
                        )}
                      </TableCell>
                    </TableRow>
                  ) : filteredProducts.map((product: any) => {
                    const stock = product.stock || 0;
                    const value = stock * parseFloat(product.price);
                    
                    return (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                              <Package className="h-5 w-5 text-muted-foreground" />
                            </div>
                            <div>
                              <p className="font-medium">{product.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {product.description?.substring(0, 50)}...
                              </p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          PRD{product.id.toString().padStart(4, '0')}
                        </TableCell>
                        <TableCell>₹{product.price}</TableCell>
                        <TableCell>
                          <span className={`font-medium ${
                            stock === 0 ? 'text-red-600' : 
                            stock < 10 ? 'text-yellow-600' : 
                            'text-green-600'
                          }`}>
                            {stock} units
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            stock === 0 ? 'destructive' : 
                            stock < 10 ? 'secondary' : 
                            'default'
                          }>
                            {stock === 0 ? 'Out of Stock' : 
                             stock < 10 ? 'Low Stock' : 
                             'In Stock'}
                          </Badge>
                        </TableCell>
                        <TableCell>₹{value.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openUpdateDialog(product)}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                            <Link href={`/products/${product.id}`}>
                              <Button size="sm" variant="outline">
                                <Eye className="h-3 w-3" />
                              </Button>
                            </Link>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Recent Inventory Logs */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Recent Inventory Changes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Array.isArray(inventoryLogs) ? inventoryLogs.slice(0, 10).map((log: any) => (
                <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      log.type === 'stock_in' ? 'bg-green-100 dark:bg-green-900' :
                      log.type === 'stock_out' ? 'bg-red-100 dark:bg-red-900' :
                      'bg-blue-100 dark:bg-blue-900'
                    }`}>
                      {log.type === 'stock_in' ? (
                        <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
                      ) : log.type === 'stock_out' ? (
                        <TrendingDown className="h-4 w-4 text-red-600 dark:text-red-400" />
                      ) : (
                        <Edit className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">
                        {log.type === 'stock_in' ? 'Stock Added' :
                         log.type === 'stock_out' ? 'Stock Removed' :
                         'Stock Adjusted'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {log.reason || 'No reason provided'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">
                      {log.type === 'stock_in' ? '+' : log.type === 'stock_out' ? '-' : '±'}
                      {Math.abs(log.quantity)} units
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(log.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              )) : (
                <p className="text-center text-muted-foreground">No inventory changes yet</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stock Update Dialog */}
      <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Stock - {selectedProduct?.name}</DialogTitle>
            <DialogDescription>
              Adjust the inventory quantity for this product. Choose whether to add, remove, or adjust stock.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleStockUpdate)} className="space-y-4">
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-sm text-muted-foreground">Current Stock</p>
                <p className="text-2xl font-bold">{selectedProduct?.stock || 0} units</p>
              </div>

              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Update Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="stock_in">Add Stock</SelectItem>
                        <SelectItem value="stock_out">Remove Stock</SelectItem>
                        <SelectItem value="adjustment">Adjust to Exact Amount</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {form.watch('type') === 'adjustment' ? 'New Stock Amount' : 'Quantity'}
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., New shipment, Damaged goods, Inventory count" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsUpdateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateStockMutation.isPending}>
                  {updateStockMutation.isPending ? 'Updating...' : 'Update Stock'}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
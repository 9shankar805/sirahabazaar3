import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { 
  Users, 
  UserCheck, 
  UserX, 
  Clock, 
  Shield, 
  Store, 
  Eye,
  CheckCircle,
  XCircle,
  AlertCircle,
  MapPin,
  Plus,
  Edit,
  Trash2,
  Save
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

export default function AdminPanel() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [adminUser, setAdminUser] = useState<any>(null);
  const [editingZone, setEditingZone] = useState<any>(null);
  const [showCreateZone, setShowCreateZone] = useState(false);
  const [newZone, setNewZone] = useState({
    name: "",
    minDistance: "",
    maxDistance: "",
    baseFee: "",
    perKmRate: "",
    isActive: true
  });

  useEffect(() => {
    const storedAdmin = localStorage.getItem("adminUser");
    if (!storedAdmin) {
      setLocation("/admin/login");
      return;
    }
    setAdminUser(JSON.parse(storedAdmin));
  }, [setLocation]);

  const { data: allUsers = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
    enabled: !!adminUser,
  });

  const { data: pendingUsers = [], isLoading: pendingLoading } = useQuery({
    queryKey: ["/api/admin/users/pending"],
    enabled: !!adminUser,
  });

  const { data: deliveryZones = [], isLoading: zonesLoading } = useQuery({
    queryKey: ["/api/delivery-zones"],
    enabled: !!adminUser,
  });

  const approveMutation = useMutation({
    mutationFn: async (userId: number) => {
      return await apiRequest(`/api/admin/users/${userId}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminId: adminUser.id }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users/pending"] });
      toast({
        title: "User approved",
        description: "The shopkeeper account has been approved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Approval failed",
        description: "Failed to approve user. Please try again.",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: number; reason: string }) => {
      return await apiRequest(`/api/admin/users/${userId}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminId: adminUser.id, reason }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users/pending"] });
      setSelectedUser(null);
      setRejectReason("");
      toast({
        title: "User rejected",
        description: "The shopkeeper application has been rejected.",
      });
    },
    onError: () => {
      toast({
        title: "Rejection failed",
        description: "Failed to reject user. Please try again.",
        variant: "destructive",
      });
    },
  });

  const createZoneMutation = useMutation({
    mutationFn: async (zoneData: any) => {
      return await apiRequest("/api/admin/delivery-zones", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(zoneData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/delivery-zones"] });
      setShowCreateZone(false);
      setNewZone({
        name: "",
        minDistance: "",
        maxDistance: "",
        baseFee: "",
        perKmRate: "",
        isActive: true
      });
      toast({
        title: "Zone created",
        description: "Delivery zone has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Creation failed",
        description: "Failed to create delivery zone.",
        variant: "destructive",
      });
    },
  });

  const updateZoneMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      return await apiRequest(`/api/admin/delivery-zones/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/delivery-zones"] });
      setEditingZone(null);
      toast({
        title: "Zone updated",
        description: "Delivery zone has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Failed to update delivery zone.",
        variant: "destructive",
      });
    },
  });

  const deleteZoneMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/delivery-zones/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/delivery-zones"] });
      toast({
        title: "Zone deleted",
        description: "Delivery zone has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Deletion failed",
        description: "Failed to delete delivery zone.",
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    localStorage.removeItem("adminUser");
    setLocation("/admin/login");
    toast({
      title: "Logged out",
      description: "You have been logged out successfully.",
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="default" className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Active</Badge>;
      case "pending":
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case "rejected":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!adminUser) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-sm text-gray-500">Siraha Bazaar Administration</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {adminUser.fullName}</span>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{allUsers.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-yellow-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Pending Approval</p>
                  <p className="text-2xl font-bold text-gray-900">{pendingUsers.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <UserCheck className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Shopkeepers</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {allUsers.filter(u => u.role === 'shopkeeper' && u.status === 'active').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Store className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Customers</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {allUsers.filter(u => u.role === 'customer').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Approvals Alert */}
        {pendingUsers.length > 0 && (
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You have {pendingUsers.length} pending shopkeeper application{pendingUsers.length > 1 ? 's' : ''} waiting for approval.
            </AlertDescription>
          </Alert>
        )}

        {/* Tabs */}
        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList>
            <TabsTrigger value="pending">
              Pending Approvals ({pendingUsers.length})
            </TabsTrigger>
            <TabsTrigger value="all">
              All Users ({allUsers.length})
            </TabsTrigger>
            <TabsTrigger value="delivery-zones">
              Delivery Zones
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            <Card>
              <CardHeader>
                <CardTitle>Pending Shopkeeper Applications</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingLoading ? (
                  <div className="text-center py-8">Loading...</div>
                ) : pendingUsers.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No pending applications
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Applied Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.fullName}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.phone}</TableCell>
                          <TableCell>{formatDate(user.createdAt)}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                onClick={() => approveMutation.mutate(user.id)}
                                disabled={approveMutation.isPending}
                              >
                                <UserCheck className="h-4 w-4 mr-1" />
                                Approve
                              </Button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => setSelectedUser(user)}
                                  >
                                    <UserX className="h-4 w-4 mr-1" />
                                    Reject
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Reject Application</DialogTitle>
                                    <DialogDescription>
                                      Are you sure you want to reject {user.fullName}'s shopkeeper application?
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div>
                                    <Textarea
                                      placeholder="Enter reason for rejection (optional)"
                                      value={rejectReason}
                                      onChange={(e) => setRejectReason(e.target.value)}
                                    />
                                  </div>
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => {
                                      setSelectedUser(null);
                                      setRejectReason("");
                                    }}>
                                      Cancel
                                    </Button>
                                    <Button
                                      variant="destructive"
                                      onClick={() => rejectMutation.mutate({
                                        userId: user.id,
                                        reason: rejectReason
                                      })}
                                      disabled={rejectMutation.isPending}
                                    >
                                      Reject Application
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Users</CardTitle>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="text-center py-8">Loading...</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Joined Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {allUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.fullName}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === 'shopkeeper' ? 'default' : 'secondary'}>
                              {user.role}
                            </Badge>
                          </TableCell>
                          <TableCell>{getStatusBadge(user.status)}</TableCell>
                          <TableCell>{formatDate(user.createdAt)}</TableCell>
                          <TableCell>
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="delivery-zones">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    Delivery Zone Management
                  </CardTitle>
                  <Dialog open={showCreateZone} onOpenChange={setShowCreateZone}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Zone
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create New Delivery Zone</DialogTitle>
                        <DialogDescription>
                          Add a new delivery zone with custom pricing.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="name" className="text-right">Name</Label>
                          <Input
                            id="name"
                            value={newZone.name}
                            onChange={(e) => setNewZone({ ...newZone, name: e.target.value })}
                            className="col-span-3"
                            placeholder="e.g., Inner City"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="minDistance" className="text-right">Min Distance (km)</Label>
                          <Input
                            id="minDistance"
                            type="number"
                            step="0.01"
                            value={newZone.minDistance}
                            onChange={(e) => setNewZone({ ...newZone, minDistance: e.target.value })}
                            className="col-span-3"
                            placeholder="0"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="maxDistance" className="text-right">Max Distance (km)</Label>
                          <Input
                            id="maxDistance"
                            type="number"
                            step="0.01"
                            value={newZone.maxDistance}
                            onChange={(e) => setNewZone({ ...newZone, maxDistance: e.target.value })}
                            className="col-span-3"
                            placeholder="5"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="baseFee" className="text-right">Base Fee (Rs.)</Label>
                          <Input
                            id="baseFee"
                            type="number"
                            step="0.01"
                            value={newZone.baseFee}
                            onChange={(e) => setNewZone({ ...newZone, baseFee: e.target.value })}
                            className="col-span-3"
                            placeholder="30.00"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="perKmRate" className="text-right">Per km Rate (Rs.)</Label>
                          <Input
                            id="perKmRate"
                            type="number"
                            step="0.01"
                            value={newZone.perKmRate}
                            onChange={(e) => setNewZone({ ...newZone, perKmRate: e.target.value })}
                            className="col-span-3"
                            placeholder="5.00"
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            id="isActive"
                            checked={newZone.isActive}
                            onCheckedChange={(checked) => setNewZone({ ...newZone, isActive: checked })}
                          />
                          <Label htmlFor="isActive">Active Zone</Label>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowCreateZone(false)}>
                          Cancel
                        </Button>
                        <Button 
                          onClick={() => createZoneMutation.mutate(newZone)}
                          disabled={createZoneMutation.isPending}
                        >
                          <Save className="h-4 w-4 mr-2" />
                          Create Zone
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {zonesLoading ? (
                  <div className="text-center py-8">Loading delivery zones...</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Zone Name</TableHead>
                        <TableHead>Distance Range</TableHead>
                        <TableHead>Base Fee</TableHead>
                        <TableHead>Per Km Rate</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Sample Fee (10km)</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(deliveryZones as any[]).map((zone) => (
                        <TableRow key={zone.id}>
                          <TableCell className="font-medium">{zone.name}</TableCell>
                          <TableCell>{zone.minDistance} - {zone.maxDistance} km</TableCell>
                          <TableCell>Rs. {zone.baseFee}</TableCell>
                          <TableCell>Rs. {zone.perKmRate}/km</TableCell>
                          <TableCell>
                            {zone.isActive ? (
                              <Badge variant="default" className="bg-green-100 text-green-800">
                                <CheckCircle className="h-3 w-3 mr-1" />Active
                              </Badge>
                            ) : (
                              <Badge variant="secondary">Inactive</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            Rs. {(parseFloat(zone.baseFee) + (10 * parseFloat(zone.perKmRate))).toFixed(2)}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingZone({ ...zone })}
                                  >
                                    <Edit className="h-4 w-4 mr-1" />
                                    Edit
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Edit Delivery Zone</DialogTitle>
                                    <DialogDescription>
                                      Modify the delivery zone pricing and settings.
                                    </DialogDescription>
                                  </DialogHeader>
                                  {editingZone && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-name" className="text-right">Name</Label>
                                        <Input
                                          id="edit-name"
                                          value={editingZone.name}
                                          onChange={(e) => setEditingZone({ ...editingZone, name: e.target.value })}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-minDistance" className="text-right">Min Distance (km)</Label>
                                        <Input
                                          id="edit-minDistance"
                                          type="number"
                                          step="0.01"
                                          value={editingZone.minDistance}
                                          onChange={(e) => setEditingZone({ ...editingZone, minDistance: e.target.value })}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-maxDistance" className="text-right">Max Distance (km)</Label>
                                        <Input
                                          id="edit-maxDistance"
                                          type="number"
                                          step="0.01"
                                          value={editingZone.maxDistance}
                                          onChange={(e) => setEditingZone({ ...editingZone, maxDistance: e.target.value })}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-baseFee" className="text-right">Base Fee (Rs.)</Label>
                                        <Input
                                          id="edit-baseFee"
                                          type="number"
                                          step="0.01"
                                          value={editingZone.baseFee}
                                          onChange={(e) => setEditingZone({ ...editingZone, baseFee: e.target.value })}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="edit-perKmRate" className="text-right">Per km Rate (Rs.)</Label>
                                        <Input
                                          id="edit-perKmRate"
                                          type="number"
                                          step="0.01"
                                          value={editingZone.perKmRate}
                                          onChange={(e) => setEditingZone({ ...editingZone, perKmRate: e.target.value })}
                                          className="col-span-3"
                                        />
                                      </div>
                                      <div className="flex items-center space-x-2">
                                        <Switch
                                          id="edit-isActive"
                                          checked={editingZone.isActive}
                                          onCheckedChange={(checked) => setEditingZone({ ...editingZone, isActive: checked })}
                                        />
                                        <Label htmlFor="edit-isActive">Active Zone</Label>
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button variant="outline" onClick={() => setEditingZone(null)}>
                                      Cancel
                                    </Button>
                                    <Button 
                                      onClick={() => updateZoneMutation.mutate({ 
                                        id: editingZone.id, 
                                        data: editingZone 
                                      })}
                                      disabled={updateZoneMutation.isPending}
                                    >
                                      <Save className="h-4 w-4 mr-2" />
                                      Update Zone
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteZoneMutation.mutate(zone.id)}
                                disabled={deleteZoneMutation.isPending}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
                
                {/* Delivery Fee Preview */}
                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold mb-3">Delivery Fee Calculator Preview</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {(deliveryZones as any[]).filter(zone => zone.isActive).map((zone) => (
                      <div key={zone.id} className="bg-white p-3 rounded border">
                        <h4 className="font-medium text-sm">{zone.name}</h4>
                        <p className="text-xs text-gray-600">{zone.minDistance}-{zone.maxDistance}km</p>
                        <div className="mt-2 space-y-1 text-xs">
                          <div>5km: Rs. {(parseFloat(zone.baseFee) + (5 * parseFloat(zone.perKmRate))).toFixed(2)}</div>
                          <div>10km: Rs. {(parseFloat(zone.baseFee) + (10 * parseFloat(zone.perKmRate))).toFixed(2)}</div>
                          <div>15km: Rs. {(parseFloat(zone.baseFee) + (15 * parseFloat(zone.perKmRate))).toFixed(2)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}